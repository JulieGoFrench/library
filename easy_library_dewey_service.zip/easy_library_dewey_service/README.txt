This module provides a dewey_service for the easy_library module.
It is only for that.
this dewey classifies the categorie and the section and returns a string ONLY for the easy_library_module
Do not use it for other modules.
