<?php
namespace Drupal\easy_library_dewey_service;
/**
 * Class DeweyService
 * @package Drupal\easy_library_dewey_service
 * for the easy-library module
 */

class DeweyService{
    public $categorie="";


    public function getClassValue(){
        return $this->get('class_value')->value;
    }


//    'information' 'philosophy' 'religion' 'social'
//   'language' 'sciences' 'technology' 'arts'
//    'literature'  'history_and_geography'



    public function deweyClass($categorie){

        if      (   $categorie == 'information'){
        $class_int = 0;
        }
        else if
        (   $categorie == 'philosophy'){
        $class_int = 1;
        }

        else if
        (   $categorie == 'religion'){
            $class_int = 2;
        }

        else if
        (   $categorie == 'social'){
            $class_int = 3;
        }

        else if
        (   $categorie == 'language'){
            $class_int = 4;
        }

        else if
        (   $categorie == 'sciences'){
            $class_int = 5;
        }

        else if
        (   $categorie == 'technology'){
            $class_int = 6;
        }

        else if
        (   $categorie == 'arts'){
            $class_int = 7;
        }

        else if
        (   $categorie == 'literature'){
            $class_int = 8;
        }

        else if
        (   $categorie == 'history_and_geography'){
            $class_int = 9;
        }

        else $class_int = 0;
        return $class_int;
    }
public $division =0;

public function deweyDivisionString($categorie, $division){
    $class = $this->deweyClass($categorie);
    $division_string="";
    $general='';
    switch ($class){
        case 0:
            $general = t('informations').' & '.t('Sports').': ';
            $division_string = $general;
            if ($division == 0){
                $division_string = $general. t("general");
            }
            if ($division == 1){
                $division_string = $division_string. t("Bibliography");
            }
            if ($division == 2){
               $division_string = $division_string. t("information").' '.t('science');
            }
            if ($division == 3){
          $division_string = $division_string. t("encyclopedic");
            }
            if ($division == 4){
      $division_string = $division_string. t("special").' '.t('topics');
            }
            if ($division == 5){
         $division_string = $division_string. t("index");
            }
            if ($division == 6){
    $division_string = $division_string. t("organisations");
            }
            if ($division == 7){
   $division_string = $division_string. t("journalism");
            }
            if ($division == 8){
   $division_string = $division_string. t("collections");
            }
            if ($division == 9){
   $division_string = $division_string.t("rare").' '.t('books');
            }
            return $division_string;
            break;

        case 1:
            $general = t('Philosophy').' & '.t('psychology').': ';
            $division_string = $general;
            if ($division == 0){
               $division_string = $general. t("general");
            }
            if ($division == 1){
                $division_string = $division_string. t("Metaphysics");
            }
            if ($division == 2){
               $division_string = $division_string. t("Humankind");
            }
            if ($division == 3){
            $division_string = $division_string. t("Paranormal");
            }
            if ($division == 4){
                $division_string = $division_string. t("Philosophy").' '.t('schools');
            }
            if ($division == 5){
         $division_string = $division_string. t("Psychology");
            }
            if ($division == 6){
        $division_string = $division_string. t("Logic");
            }
            if ($division == 7){
             $division_string = $division_string. t("Ethics");
            }
            if ($division == 8){
            $division_string = $division_string.t("Ancient").' '.t('Philosophy');
            }
            if ($division == 9){
               $division_string = $division_string.t("Modern").' '.t('Philosophy');
            }
            return $division_string;
            break;
        case 2:
            $general = t('Religion').': ';
            $division_string = $general;
            if ($division == 0){
                $division_string = $general. t("general");
            }
            if ($division == 1){
                $division_string = $division_string.t("Natural").' '.t('theology');
            }
            if ($division == 2){
                $division_string = $division_string.t("Bible");
            }
            if ($division == 3){
                $division_string = $division_string.t('theology');
            }
            if ($division == 4){
                $division_string = $division_string.t("Moral");
            }
            if ($division == 5){
                $division_string = $division_string.t('church');
            }
            if ($division == 6){
                $division_string = $division_string.t("Social").' '.t('theology');
            }
            if ($division == 7){
                $division_string = $division_string.t("History");
            }
            if ($division == 8){
                $division_string = $division_string.t("denominations");
            }
            if ($division == 9){
                $division_string = $division_string.t('Other');
            }
            return $division_string;
            break;
        case 3:
            $general = t('Social').': ';
          $division_string = $general. t("general");
            if ($division == 0){
                $division_string = $general;
            }
            if ($division == 1){
                $division_string = $division_string.t("Statistics");
            }
            if ($division == 2){
                $division_string = $division_string.t("Political");
            }
            if ($division == 3){
                $division_string = $division_string.t("Economics");
            }
            if ($division == 4){
                $division_string = $division_string. t("Law");
            }
            if ($division == 5){
                $division_string = $division_string. t("Administration");
            }
            if ($division == 6){
                $division_string = $division_string.t("Social").' '.t('problems');
            }
            if ($division == 7){
                $division_string = $division_string. t("Education");
            }
            if ($division == 8){
                $division_string = $division_string. t("Commerce");
            }
            if ($division == 9){
                $division_string = $division_string.t("Folklore");
            }
            return $division_string;
            break;
        case 4:
            $general = t('Language').': ';
          $division_string = $general. t("general");               
           if ($division == 0){
               $division_string = $general;
           }
           if ($division == 1){
               $division_string = $division_string.t("Linguistics");
           }
           if ($division == 2){
               $division_string = $division_string.t("English");
           }
           if ($division == 3){
               $division_string = $division_string.t("Germanic").' '.t('languages');
           }
           if ($division == 4){
               $division_string = $division_string.t("French");
           }
           if ($division == 5){
               $division_string = $division_string. t("Italian");
           }
           if ($division == 6){
               $division_string = $division_string.t("Spanish").' & '.t('Portuguese ');
           }
           if ($division == 7){
               $division_string = $division_string. t("Latin");
           }
           if ($division == 8){
               $division_string = $division_string. t("Greek");
           }
           if ($division == 9){
               $division_string = $division_string.t("Other").' '.t('languages');
           }
            return $division_string;
            break;
   case 5:
    $general = t('Science').': ';
   $division_string = $general. t("general");
    if ($division == 0){
        $division_string = $general;
    }
    if ($division == 1){
        $division_string = $division_string.t("Mathematics");
    }
    if ($division == 2){
        $division_string = $division_string.t("Astronomy");
    }
    if ($division == 3){
        $division_string = $division_string.t("Physics");
    }
    if ($division == 4){
        $division_string = $division_string. t("Chemistry");
    }
    if ($division == 5){
        $division_string = $division_string.t("Earth").' '.t('sciences');
    }
    if ($division == 6){
        $division_string = $division_string.t("Paleontology");
    }
    if ($division == 7){
        $division_string = $division_string.t("Life").' '.t('sciences');
    }
    if ($division == 8){
        $division_string = $division_string. t("Botanical");
    }
    if ($division == 9){
        $division_string = $division_string.t("Zoological");
    }
      return $division_string;

     break;
      case 6:
           $general = t('Technology').': ';
           $division_string = $general;                             
  if ($division == 0){
   $division_string = $general. t("general");
  }
  if ($division == 1){
      $division_string = $division_string.t("Medical");
  }
  if ($division == 2){
      $division_string = $division_string.t("Engineering");
  }
  if ($division == 3){
      $division_string = $division_string.t("Agriculture");
  }
  if ($division == 4){
      $division_string = $division_string.t("Domestic");
  }
  if ($division == 5){
      $division_string = $division_string. t("Management");
  }
  if ($division == 6){
      $division_string = $division_string.t("Chemical ").' '.t('engineering');
  }
  if ($division == 7){
      $division_string = $division_string. t("Manufacturing");
  }
  if ($division == 8){
      $division_string = $division_string.t("Special ").'  '.t('manufacturing');
  }
  if ($division == 9){
      $division_string = $division_string.t("Buildings");
  }
   return $division_string;
   break;

   case 7:
        $general = t('Arts').': ';
         $division_string = $general;

           if ($division == 0){
           $division_string = $general. t("general");
           }
           if ($division == 1){
               $division_string = $division_string.t("Landscape");
           }
           if ($division == 2){
               $division_string = $division_string.t("Architecture");
           }
           if ($division == 3){
               $division_string = $division_string.t("Sculpture");
           }
           if ($division == 4){
               $division_string = $division_string. t("Drawing");
           }
           if ($division == 5){
               $division_string = $division_string. t("Painting");
           }
           if ($division == 6){
               $division_string = $division_string.t("Printmaking ");
           }
           if ($division == 7){
               $division_string = $division_string. t("Photography");
           }
           if ($division == 8){
               $division_string = $division_string. t("Music");
           }
           if ($division == 9){
               $division_string = $division_string.t("Performing");
           }
             return $division_string;
             break;

       case 8:
             $general = t('Literature').': ';
            $division_string = $general. t("general");

           if ($division == 0){
               $division_string = $general;
           }
           if ($division == 1){
               $division_string = $division_string.t("American");
           }
           if ($division == 2){
               $division_string = $division_string.t("English");
           }
           if ($division == 3){
                 $division_string = $division_string.t("Germanic");
           }
           if ($division == 4){
               $division_string = $division_string. t("Romance ");
           }
           if ($division == 5){
               $division_string = $division_string. t("Italian");
           }
           if ($division == 6){
               $division_string = $division_string.t("Spanish").' & '.t('Portuguese ');  
           }
           if ($division == 7){
               $division_string = $division_string. t("Latin");
           }
           if ($division == 8){
               $division_string = $division_string. t("Greek");
           }
           if ($division == 9){
               $division_string = $division_string.t("Other");
           }
             return $division_string;
             break;


        case 9:
           $general = t('History'). ' & '.t('Geography ').': ';
           $division_string = $general;

           if ($division == 0){
  $division_string = $general. t("general");                          
           }
           if ($division == 1){
               $division_string = $division_string.t("Travel");
           }
           if ($division == 2){
               $division_string = $division_string.t("Biography");
           }
           if ($division == 3){
               $division_string = $division_string.t("History").' '.t('old');
           }
           if ($division == 4){
             $division_string = $division_string.t("Europe");
           }
           if ($division == 5){
             $division_string = $division_string.t("Asia ");
           }
           if ($division == 6){
             $division_string = $division_string.t("Africa ");
           }
           if ($division == 7){
             $division_string = $division_string.t("North ").' '.t('america');
           }
           if ($division == 8){
             $division_string = $division_string.t("South ").' '.t('america');
           }
           if ($division == 9) {
             $division_string = $division_string.t("Other ");
           }

            return $division_string;
            break;
    }
                return $division_string;  
}

// end function division pfou

}
