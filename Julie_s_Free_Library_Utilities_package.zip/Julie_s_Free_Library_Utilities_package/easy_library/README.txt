This module provides a module to classify documents for a library
go to the path /easy-library to add documents, edit them etc..
and to /admin/structure/easy-library to add new fields or
hide existing fields.
When you first edit a document the default subscriber is none
or non translated in your language if your site is not in english.
CAUTION : Needs the easy_library_dewey_service and
easy_library_subscribers modules to be installed before.



