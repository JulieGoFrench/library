<?php

namespace Drupal\easy_library;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Access controller for the easy_library entity.
 *
 * @see \Drupal\comment\Entity\Comment.
 */
class EasyLibraryAccessControlHandler extends EntityAccessControlHandler {

    protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
        switch ($operation) {
            case 'view':
                return AccessResult::allowedIfHasPermission($account, 'view an easy_library object');

            case 'edit':
                return AccessResult::allowedIfHasPermission($account, 'edit an easy_library object');

            case 'delete':
                return AccessResult::allowedIfHasPermission($account, 'delete an easy_library object');
        }
        return AccessResult::allowed();
    }

    protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
        return AccessResult::allowedIfHasPermission($account, 'add an easy_library object');
    }

}
