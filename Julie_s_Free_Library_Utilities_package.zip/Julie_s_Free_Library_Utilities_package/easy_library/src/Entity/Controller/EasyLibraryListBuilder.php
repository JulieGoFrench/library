<?php
namespace Drupal\easy_library\Entity\Controller;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Routing\UrlGeneratorInterface;
use Drupal\easy_library\Entity\EasyLibrary;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\easy_library_dewey_service;
use Drupal\easy_library_dewey_service\DeweyService;


/**
 * Provides a list controller for easy_library.
 *
 * @ingroup easy_library
 */

class EasyLibraryListBuilder extends EntityListBuilder  {
    /**
     * The url generator.
     *
     * @var \Drupal\Core\Routing\UrlGeneratorInterface
     */
    protected $urlGenerator;
//    protected $deweyService;

    protected $library_manager;

    public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
        return new static(
            $entity_type,
            $container->get('entity.manager')->getStorage($entity_type->id()),
            $container->get('url_generator'),
            $container->get('easy_library_service.dewey')

        );
    }

    public function __construct(EntityTypeInterface $entity_type, EntityStorageInterface $storage, UrlGeneratorInterface $url_generator,
                                DeweyService $deweyService) {
        parent::__construct($entity_type, $storage);
        $this->urlGenerator = $url_generator;
        $this->library_manager = $deweyService;
    }
// . 'result : ' . $this->library_manager->deweyClass(t("Philosophy"))
    public function render() {
        $build['description'] = array(
            '#markup' => $this->t('List of Documents') ,
        );
        $build['table'] = parent::render();
        return $build;
    }

      public function buildHeader() {

        $header['title'] = $this->t('title');
        $header['author'] = $this->t('author');
        $header['mediatype'] = $this->t('media').t('type');
        $header['category'] = $this->t('category');
//        $header['division'] = $this->t('division').' Dewey';
        $header['section'] = $this->t('section');
        $header['status'] = $this->t('Available');
        $header['subscriberfirstname'] = $this->t('First').' '.t('name');
        $header['subscribersname'] = $this->t('Second').' '.t('name');
        $header['contact'] = "contact";
        $header['borroweddate'] = $this->t('Start date');
        $header['duetoreturndate'] = $this->t('End date');

         return $header + parent::buildHeader();
    }

    public function buildRow(EntityInterface $entity) {

        $available = $this->t('no');
        if ($entity->status->value == TRUE ){
            $available = $this->t('yes');
        }
        $pseudo_bool=true;
        $firstName = $entity->subscriberfirstname->value;
        $name= $entity->subscribersname ->value;

        if ($name == t('none')){
            $name=" ";
            $firstName= "";
            $available = $this->t('yes');
            $pseudo_bool = false;
        }
        $row['title'] = $entity->title->value;
        $row['author'] =  $entity->author->value;
        $row['mediatype'] = $entity->mediatype->value;
        $class= $entity->class->value;
        $division = $entity->division->value;
        $category = $this->library_manager->deweyDivisionString($class, $division);
        $row['category'] =  $category;
        $row['section'] =  $entity->section->value;

        $row['status'] = $available;
        $row['subscriberfirstname'] =$firstName;
        $row['subscribersname'] =$name;

        if ($pseudo_bool ==false){
            $row['contact'] ='';
        }else $row['contact'] =$entity->contact->value;

        if ($pseudo_bool ==false){
            $row['borroweddate'] ='';
        }else $row['borroweddate'] =$entity->borroweddate->value;

        if ($pseudo_bool ==false){
            $row['duetoreturndate'] ='';
        } else $row['duetoreturndate'] = $entity->duetoreturndate->value;


        return $row + parent::buildRow($entity);
    }



}

