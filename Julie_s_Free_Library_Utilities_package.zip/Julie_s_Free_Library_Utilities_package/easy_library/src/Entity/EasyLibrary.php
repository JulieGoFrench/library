<?php

namespace Drupal\easy_library\Entity;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use \Drupal\Core\Database\Database;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * Defines the EasyLibrary
 *
 * @ingroup easy_library
 *
 * @ContentEntityType(
 *   id = "easy_library",
 *   label = @Translation("EasyLibrary"),
 *   base_table = "easy_library",
 *   entity_keys = {
 *     "uuid" = "uuid",
 *     "id" = "id",
 *     "title" = "title",
 *     "author" = "author",
 *     "mediatype" = "mediatype",
 *     "class" = "class",
 *     "division" = "division",
 *     "section" = "section",
 *      "status" = "status",
 *     "subscriberfirstname" = "subscriberfirstname",
 *     "subscribersname" = "subscribersname",
 *     "contact" = "contact",
 *     "borroweddate"= "borroweddate",
 *     "duetoreturndate" = "duetoreturndate",
 *   },
 *     admin_permission = "administer easy_library entity",
 *     field_ui_base_route = "easy_library.library_settings",
 *    handlers = {
 *      "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *      "list_builder" = "Drupal\easy_library\Entity\Controller\EasyLibraryListBuilder",
 *      "access" = "Drupal\easy_library\EasyLibraryAccessControlHandler",
 *     "form" = {
 *       "add" = "Drupal\easy_library\Form\EasyLibraryForm",
 *      "edit" = "Drupal\easy_library\Form\EasyLibraryForm",
 *     "delete" = "Drupal\easy_library\Form\EasyLibraryDeleteForm",
 *      },
 *     },
 *     links = {
 *     "canonical" = "/see-easy-document/{easy_library}",
 *     "edit-form" = "/easy-document/{easy_library}/edit",
 *     "delete-form" = "/easy-document/{easy_library}/delete",
 *      "collection" = "/easy-library"
 *
 *     },
 * )
 */
//*
// *      "adress" = "adress",
class EasyLibrary extends ContentEntityBase
{

    function returnLibraryTranslate(){
        return t('library');
    }

    function library_tool_entity_update(Drupal\Core\Entity\EntityInterface $entity)
    {
        $connection = \Drupal\Core\Database\Database::getConnection();
        $requestTime = \Drupal::time()->getRequestTime();

        $connection->update('easy_library')
            ->fields(array(
                'updated' => $requestTime,
            ))
            ->condition('type', $entity
                ->getEntityTypeId())
            ->condition('id', $entity
                ->id());

    }


    public static function baseFieldDefinitions(EntityTypeInterface $entity_type)
    {
// UUID
        $fields['uuid'] = BaseFieldDefinition::create('uuid')
            ->setLabel(t('UUID'))
            ->setDescription(t('The UUID of the easy library entity.'))
            ->setReadOnly(TRUE);

        // ID
        $fields['id'] = BaseFieldDefinition::create('integer')
            ->setLabel(t('ID'))
            ->setDescription(t('The ID of the Entity.'))
            ->setReadOnly(TRUE);

        // title field
        $fields['title'] = BaseFieldDefinition::create('string_long')
            ->setLabel(t('title'))
            ->setRequired(TRUE)
            ->setSettings(array(
                'default_value' => '_',
                'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -11,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -11,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);
// Author
        $fields['author'] = BaseFieldDefinition::create('string_long')
            ->setLabel(t('author'))
            ->setRequired(TRUE)
            ->setSettings(array(
                'default_value' => '_',
                'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -10,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -10,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);

// media type

        $fields['mediatype'] = BaseFieldDefinition::create('string_long')
            ->setLabel(t('media type'))
            ->setRequired(TRUE)
            ->setSettings(array(
                'default_value' => '_',
                'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -9,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -9,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);


        // classe Dewey
        $fields['class'] = BaseFieldDefinition::create('list_string')
            ->setSettings([
                'allowed_values' => ['information' => t('Information').' & '.t("Sport"),
                    'philosophy' => t("Philosophy"),
                    'religion'=>t("Religion"), 'social' => t("Social"),
                    'language' => t("Language"),
                    'sciences' => t("Sciences"),
                    'technology' => t("Technology"),
                    'arts'=> t("Arts"),
                    'literature' => t("Literature"),
                    'history_and_geography' => t("History").' &' .t("Geography") ]
            ])
            ->setLabel('Category')
            ->setDescription(t('Category '))
            ->setRequired(TRUE)
            ->setCardinality(-1)
            ->setDisplayOptions('form', array(
                'type' => 'options_buttons',
                'weight' => -8,
            ))
            ->setDisplayConfigurable('form', TRUE);

        $fields['division'] = BaseFieldDefinition::create('integer')
            ->setLabel(t('division').' Dewey')
            ->setRequired(FALSE)
            ->setDefaultValue(0)
            ->addPropertyConstraints('value', [
                'Range' => [
                    'min' => 0,
                    'max' => 9,
                ],
            ])
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'number_integer',
                'weight' => -7,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'number',
                'weight' => -7,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);

        // section dewey
        $fields['section'] = BaseFieldDefinition::create('integer')
            ->setLabel(t('section').' Dewey')
            ->setRequired(FALSE)
            ->setDefaultValue(0)
            ->addPropertyConstraints('value', [
                'Range' => [
                    'min' => 0,
                    'max' => 9,
                ],
            ])
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'number_integer',
                'weight' => -6,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'number',
                'weight' => -6,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);

        //status

        $fields['status'] = BaseFieldDefinition::create('boolean')
            ->setLabel(t(" not available"))
             ->setDisplayOptions('form', array(
                'type' => 'boolean_checkbox',
                'settings' => array(
                    'default_value' => FALSE,
                    'display_label' => TRUE,
                ),
                'weight' => -5,
            ))
            ->setDisplayConfigurable('form', TRUE);


        // subscriber_first_name
        $fields['subscriberfirstname'] = BaseFieldDefinition::create('string_long')
            ->setRequired(FALSE)
            ->setDefaultValue(t('none'))
            ->setLabel(t('First').' '.t('name')
                .' '.t('Write').' '.t('none').' '.t('If').' '.t('none'))
            ->setSettings(array(
                 'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -4,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -4,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);



        // subscriber name

        $fields['subscribersname'] = BaseFieldDefinition::create('string_long')
            ->setRequired(TRUE)
            ->setDefaultValue(t('none'))
            ->setLabel(t('Second').' '.t('name')
                .' '.t('Write').' '.t('none').' '.t('If').' '.t('none'))
            ->setSettings(array(
                'default_value' => 'a',
                'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -3,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -3,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);
//// contact
        $fields['contact'] = BaseFieldDefinition::create('string_long')
            ->setRequired(TRUE)
            ->setDefaultValue(t('none'))
            ->setLabel(t('contact').' '.t('Reader'))
            ->setSettings(array(
                'default_value' => 'a',
                'max_length' => 100,
                'text_processing' => 0,
            ))
            ->setDisplayOptions('view', array(
                'label' => 'above',
                'type' => 'basic_string',
                'weight' => -3,
            ))
            ->setDisplayOptions('form', array(
                'type' => 'string_textarea',
                'weight' => -3,
            ))
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);

// dates
        $today =  date("Y-m-d");
        $default_time2 = "2019-02-02";

        $fields['borroweddate'] = BaseFieldDefinition::create('datetime')
        ->setLabel(t('Start date'))
        ->setRequired(FALSE)
        ->setDescription(t('Start date.'))
        ->setSettings([
            'datetime_type' => 'date',
        ])
        ->setDefaultValue($today)
        ->setDisplayOptions('view', [
            'label' => 'above',
            'type' => 'datetime_default',
            //               '#default_value' => DrupalDateTime::createFromTimestamp(strtotime($config->get('start_date'))),
            'settings' => [
                'format_type' => 'medium',
            ],
            'weight' => -2,
        ])
        ->setDisplayOptions('form', [
            'type' => 'datetime_default',
            'weight' => -2,
        ])
        ->setDisplayConfigurable('form', TRUE)
        ->setDisplayConfigurable('view', TRUE);

//"duetoreturndate"

        $fields['duetoreturndate'] = BaseFieldDefinition::create('datetime')
            ->setLabel(t('End date'))
            ->setRequired(FALSE)
            ->setDescription(t('End  date.'))
            ->setSettings([
                'datetime_type' => 'date',
            ])
            ->setDefaultValue($today)
            ->setDisplayOptions('view', [
                'label' => 'above',
                'type' => 'datetime_default',
                'settings' => [
                    'format_type' => 'medium',
                ],
                'weight' => -2,
            ])
            ->setDisplayOptions('form', [
                'type' => 'datetime_default',
                'weight' => -2,
            ])
            ->setDisplayConfigurable('form', TRUE)
            ->setDisplayConfigurable('view', TRUE);

        return $fields;
    }



// getters

    public function getName()
    {
        return $this->get('name')->value;
    }

    public function getTitle()
    {
        return $this->get('title')->value;
    }

    public function getAuthor()
    {
        return $this->get('author')->value;
    }

    public function getMediatype()
    {
        return $this->get('mediatype')->value;
    }

    public function getClass()
    {
        return $this->get('class')->value;
    }

    public function getDivision()
    {
        return $this->get('division')->value;
    }

    public function getSection()
    {
        return $this->get('section')->value;
    }

    public function getSubscribersName()
    {
        return $this->get('subscribersname')->value;
    }

    public function getFirstName()
    {
        return $this->get('subscriberfirstname')->value;
    }

    public function getStatus()
    {
        return $this->get('status')->value;
    }

    public function getBorrowedDate()
    {
        return $this->get('borroweddate')->value;
    }

    public function getDuetoreturndate()
    {
        return $this->get('duetoreturndate')->value;
    }

// setters

    public function setTitle($title)
    {
        $this->get('title')->value = $title;
        return $this;
    }

    public function setAuthor($author)
    {
        $this->get('author')->value = $author;
        return $this;

    }

    public function setMediatype($mediatype)
    {
        $this->get('mediatype')->value = $mediatype;
        return $this;
    }

    public function setClass($class)
    {
        $this->get('class')->value = $class;
        return $this;
    }

    public function setDivision($division)
    {
        $this->get('division')->value = $division;
        return $this;
    }

    public function setSection($section)
    {
        $this->get('section')->value = $section;
        return $this;
    }

    public function setSubscribersName($subscribersname)
    {
        $this->get('subscribersname')->value = $subscribersname;
        return $this;
    }

    public function setFirstName($subscriberfirstname)
    {
        $this->get('subscriberfirstname')->value = $subscriberfirstname;
        return $this;
    }

    public function setStatus($status)
    {
        $this->get('status')->value = $status;
        return $this;
    }

    public function setBorrowedDate($borroweddate)    {
        $this->get('borroweddate')->value = $borroweddate;
        return $this;
    }

    public function setDuetoreturndate($duetoreturndate)    {
        $this->get('duetoreturndate')->value = $duetoreturndate;
        return $this;
    }


}



