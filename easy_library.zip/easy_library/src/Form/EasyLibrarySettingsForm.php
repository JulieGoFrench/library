<?php

namespace Drupal\easy_library\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class EasyLibrarySettingsForm.
 *
 * @package Drupal\easy_library\Form
 *
 * @ingroup easy_library
 */
class EasyLibrarySettingsForm extends FormBase {

    public function getFormId() {
        return 'easy_library_settings';
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {

    }

    public function buildForm(array $form, FormStateInterface $form_state) {
        $form['easy_library']['#markup'] = 'Settings form for the easy library module. Manage field settings here.';
        return $form;
    }
}