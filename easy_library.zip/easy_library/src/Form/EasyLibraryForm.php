<?php

namespace Drupal\easy_library\Form;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Language\Language;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\easy_library_dewey_service;
use Drupal\easy_library_dewey_service\DeweyService;

/**
 * Form controller for the easy_library add/edit forms.
 *
 * @ingroup easy_library
 */
class EasyLibraryForm extends ContentEntityForm {

     public function buildForm(array $form, FormStateInterface $form_state) {

            $form = parent::buildForm($form, $form_state);
            $entity = $this->entity;

            return $form;

        }

    public function save(array $form, FormStateInterface $form_state) {
            $entity = $this->getEntity();
            $entity->save();
            $form_state->setRedirect('entity.easy_library.canonical', ['easy_library'=>$entity->id()]);

        }


}
