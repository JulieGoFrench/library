<?php

namespace Drupal\easy_library\Form;
use Drupal\Core\Entity\ContentEntityConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;



/**
 * Provides a fom for deleting a easy_library entity.
 * @ingroup easy_library
 */

class EasyLibraryDeleteForm extends ContentEntityConfirmFormBase {

    /**
     * {@inheritdoc}
     */
    public function getQuestion() {
        return $this->t('Are you sure you want to delete entity %name?', array('%name' => $this->entity->label()));
    }

    public function getCancelUrl() {
        return new Url('entity.easy_library.collection');
    }

    public function getConfirmText() {
        return $this->t('Delete');
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $entity = $this->getEntity();
        $entity->delete();

        $this->logger('easy_library')->notice('@type: deleted %title.',
            array(
                '@type' => $this->entity->bundle(),
                '%title' => $this->entity->label(),
            ));
        $form_state->setRedirect('entity.easy_library.collection');
    }

}